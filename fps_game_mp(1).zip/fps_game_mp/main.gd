extends Node3D
## The level plus all the multiplayer game logic.
##
## Network model (listen server): one player hosts and is peer id 1.
## - Every player moves their own character and tells the others where it is.
## - The shooter's game decides what a bullet hit; the host applies damage,
##   tracks health, and announces kills and respawns.
## Works offline too (an offline game counts as "the server").

const GunScript := preload("res://gun.gd")
const PlayerScene := preload("res://player.tscn")
const NetScript := preload("res://net.gd")
const MENU_SCENE := "res://menu.tscn"

const RESPAWN_TIME := 3.0
const SPAWNS := [
	Vector3(0, 0.05, 12), Vector3(6, 0.05, 12), Vector3(-6, 0.05, 12),
	Vector3(0, 0.05, 20), Vector3(12, 0.05, 8), Vector3(-12, 0.05, 8),
	Vector3(8, 0.05, 20), Vector3(-8, 0.05, 20),
]

var players_root: Node3D
var feed_label: Label
var feed: Array = []

func _ready() -> void:
	_setup_environment()
	_build_level()
	_build_feed()

	players_root = Node3D.new()
	players_root.name = "Players"
	add_child(players_root)

	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.server_disconnected.connect(_on_server_disconnected)

	if multiplayer.is_server():
		# Host (or offline): spawn our own player straight away
		spawn_player(1, _pick_spawn())
	else:
		# Client: ask the host to spawn everyone for us
		client_ready.rpc_id(1)

func _pick_spawn() -> Vector3:
	return SPAWNS[randi() % SPAWNS.size()]

# ================================================================ players

# A client tells the host its level is loaded.
@rpc("any_peer", "call_remote", "reliable")
func client_ready() -> void:
	if not multiplayer.is_server():
		return
	var id := multiplayer.get_remote_sender_id()
	# Tell the newcomer about everyone already here...
	for child in players_root.get_children():
		var existing := child as Node3D
		spawn_player.rpc_id(id, int(str(existing.name)), existing.global_position)
	# ...then spawn the newcomer for everyone (including the host and themselves)
	spawn_player.rpc(id, _pick_spawn())

@rpc("authority", "call_local", "reliable")
func spawn_player(id: int, pos: Vector3) -> void:
	if players_root.has_node(str(id)):
		return
	var p := PlayerScene.instantiate() as Node3D
	p.name = str(id)
	p.set_multiplayer_authority(id)   # the owner controls this player
	p.position = pos
	players_root.add_child(p, true)

@rpc("authority", "call_local", "reliable")
func despawn_player(id: int) -> void:
	var p := players_root.get_node_or_null(str(id))
	if p:
		p.queue_free()

func _on_peer_disconnected(id: int) -> void:
	if multiplayer.is_server():
		despawn_player.rpc(id)

func _on_server_disconnected() -> void:
	NetScript.leave(multiplayer)
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	get_tree().change_scene_to_file(MENU_SCENE)

# ================================================================ combat

# Called by the local gun when a shot hits another player.
func hit_player(target_id: int, amount: float) -> void:
	if multiplayer.is_server():
		_apply_damage(target_id, amount, 1)
	else:
		report_hit.rpc_id(1, target_id, amount)

@rpc("any_peer", "call_remote", "reliable")
func report_hit(target_id: int, amount: float) -> void:
	if not multiplayer.is_server():
		return
	_apply_damage(target_id, clampf(amount, 0.0, 150.0), multiplayer.get_remote_sender_id())

# Host only: subtract health and announce the result.
func _apply_damage(target_id: int, amount: float, shooter_id: int) -> void:
	var target := players_root.get_node_or_null(str(target_id))
	if target == null or bool(target.get("dead")) or target_id == shooter_id:
		return
	var hp := maxf(float(target.get("health")) - amount, 0.0)
	set_health.rpc(target_id, hp)
	if hp <= 0.0:
		announce_kill.rpc(target_id, shooter_id)
		_schedule_respawn(target_id)

@rpc("authority", "call_local", "reliable")
func set_health(id: int, hp: float) -> void:
	var p = players_root.get_node_or_null(str(id))
	if p:
		p.set_health(hp)

@rpc("authority", "call_local", "reliable")
func announce_kill(victim: int, killer: int) -> void:
	_add_feed("Player %d eliminated Player %d" % [killer, victim])

func _schedule_respawn(id: int) -> void:
	await get_tree().create_timer(RESPAWN_TIME).timeout
	if players_root.has_node(str(id)):
		respawn_player.rpc(id, _pick_spawn())

@rpc("authority", "call_local", "reliable")
func respawn_player(id: int, pos: Vector3) -> void:
	var p = players_root.get_node_or_null(str(id))
	if p:
		p.respawn(pos)

# Called by the local gun after every shot, so others see flashes and impacts.
func broadcast_shot(weapon_idx: int, positions: PackedVector3Array, normals: PackedVector3Array, holes: PackedByteArray) -> void:
	if multiplayer.get_peers().size() > 0:
		shot_fx.rpc(weapon_idx, positions, normals, holes)

@rpc("any_peer", "call_remote", "unreliable")
func shot_fx(weapon_idx: int, positions: PackedVector3Array, normals: PackedVector3Array, holes: PackedByteArray) -> void:
	var shooter = players_root.get_node_or_null(str(multiplayer.get_remote_sender_id()))
	if shooter:
		shooter.remote_shot(weapon_idx)
	for i in positions.size():
		GunScript.spawn_impact(self, positions[i], normals[i], i < 3, holes[i] == 1)

# ================================================================ kill feed

func _build_feed() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	feed_label = Label.new()
	feed_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	layer.add_child(feed_label)
	feed_label.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	feed_label.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT, Control.PRESET_MODE_MINSIZE, 12)

func _add_feed(text: String) -> void:
	feed.append({"text": text, "t": Time.get_ticks_msec() / 1000.0})
	if feed.size() > 5:
		feed.pop_front()

func _process(_delta: float) -> void:
	var now := Time.get_ticks_msec() / 1000.0
	var keep: Array = []
	var lines := PackedStringArray()
	for e in feed:
		if now - float(e.t) < 6.0:
			keep.append(e)
			lines.append(String(e.text))
	feed = keep
	feed_label.text = "\n".join(lines)

# ================================================================ level

func _setup_environment() -> void:
	var env := Environment.new()
	var sky := Sky.new()
	sky.sky_material = ProceduralSkyMaterial.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-50, -30, 0)
	sun.shadow_enabled = true
	add_child(sun)

# pos = center of the box, size = full size
func _box(pos: Vector3, size: Vector3, color: Color) -> void:
	var body := StaticBody3D.new()
	body.position = pos
	var mesh := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	bm.material = mat
	mesh.mesh = bm
	var col := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = size
	col.shape = bs
	body.add_child(mesh)
	body.add_child(col)
	add_child(body)

# A tunnel along the Z axis: a slab with side walls. "bottom" = clearance height.
func _tunnel(x: float, z: float, bottom: float, color: Color) -> void:
	var slab_h := 1.0
	_box(Vector3(x, bottom + slab_h * 0.5, z), Vector3(6, slab_h, 4), color)
	var wall_h := bottom + slab_h
	_box(Vector3(x - 3.25, wall_h * 0.5, z), Vector3(0.5, wall_h, 4), color)
	_box(Vector3(x + 3.25, wall_h * 0.5, z), Vector3(0.5, wall_h, 4), color)

# Every player builds the exact same level, so nothing here is random per machine.
func _build_level() -> void:
	# Floor (top surface at y = 0)
	_box(Vector3(0, -0.5, 0), Vector3(100, 1, 100), Color(0.25, 0.27, 0.3))

	# Wall-jump shaft: two tall walls 3m apart, platform at the top
	var wall_color := Color(0.7, 0.45, 0.3)
	_box(Vector3(-2, 4.5, -10), Vector3(1, 9, 8), wall_color)
	_box(Vector3(2, 4.5, -10), Vector3(1, 9, 8), wall_color)
	_box(Vector3(0, 6.5, -18), Vector3(6, 1, 8), Color(0.4, 0.7, 0.4))

	# Crouch-only tunnel (clearance 1.5m: crouch 1.2 fits, standing 1.8 does not)
	_tunnel(-14, 0, 1.5, Color(0.35, 0.5, 0.8))
	# Crawl-only tunnel (clearance 0.9m: crawl 0.6 fits, crouch 1.2 does not)
	_tunnel(-14, -8, 0.9, Color(0.8, 0.4, 0.5))

	# Jump platforms
	_box(Vector3(10, 0.5, 0), Vector3(4, 1, 4), Color(0.8, 0.75, 0.4))
	_box(Vector3(15, 1.0, 0), Vector3(4, 2, 4), Color(0.8, 0.65, 0.4))
	_box(Vector3(20, 1.5, 0), Vector3(4, 3, 4), Color(0.8, 0.55, 0.4))

	# Pillars for cover (fixed seed = identical on every machine).
	# Kept clear of the spawn area.
	var rng := RandomNumberGenerator.new()
	rng.seed = 12345
	for i in 25:
		var p := Vector3(rng.randf_range(-40, 40), 1.5, rng.randf_range(-5, 40))
		if absf(p.x) < 16 and p.z > 2 and p.z < 30:
			continue
		_box(p, Vector3(1, 3, 1), Color(0.5, 0.5, 0.55))
