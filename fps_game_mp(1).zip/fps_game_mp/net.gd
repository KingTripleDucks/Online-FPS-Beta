extends RefCounted
## Network helpers (used via preload, no autoload needed).
## One player hosts (listen server, peer id 1); everyone else joins by IP.

const PORT := 7777
const MAX_PLAYERS := 8

static func host(api: MultiplayerAPI) -> Error:
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_server(PORT, MAX_PLAYERS)
	if err != OK:
		return err
	api.multiplayer_peer = peer
	return OK

static func join(api: MultiplayerAPI, address: String) -> Error:
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_client(address, PORT)
	if err != OK:
		return err
	api.multiplayer_peer = peer
	return OK

# Disconnect and go back to offline mode (which also acts as single player)
static func leave(api: MultiplayerAPI) -> void:
	var peer := api.multiplayer_peer
	if peer != null and not (peer is OfflineMultiplayerPeer):
		peer.close()
	api.multiplayer_peer = OfflineMultiplayerPeer.new()
