extends Node3D
## Hitscan weapon system: pistol, assault rifle, shotgun.
## Created by player.gd as a child of the local player's Camera3D.
## Switch with 1 / 2 / 3 or the mouse wheel.

const LOWERED_OFFSET := Vector3(0, -0.25, 0.05)
const INFINITE_AMMO_THRESHOLD := 9999   # reserve above this is shown as INF

# All weapon stats live here. To tweak a gun or add a new one, edit this list.
const WEAPONS := [
	{
		"name": "Pistol",
		"damage": 25.0, "pellets": 1, "fire_rate": 6.0, "automatic": false,
		"spread": 0.003, "moving_spread": 0.0006,
		"mag_size": 12, "reserve": 999999, "reload_time": 1.3, "shell_reload": false,
		"recoil_pitch": 0.02, "recoil_yaw": 0.004, "recovery": 12.0, "kickback": 0.06,
		"impact_force": 10.0,
		"body": Vector3(0.05, 0.11, 0.22), "barrel_len": 0.05, "barrel_r": 0.018,
		"mag": Vector3(0.04, 0.12, 0.05), "color": Color(0.15, 0.15, 0.17),
		"hip": Vector3(0.2, -0.18, -0.4),
	},
	{
		"name": "Assault Rifle",
		"damage": 20.0, "pellets": 1, "fire_rate": 11.0, "automatic": true,
		"spread": 0.004, "moving_spread": 0.0008,
		"mag_size": 30, "reserve": 999999, "reload_time": 2.0, "shell_reload": false,
		"recoil_pitch": 0.05, "recoil_yaw": 0.005, "recovery": 12.0, "kickback": 0.2,
		"impact_force": 8.0,
		"body": Vector3(0.06, 0.11, 0.5), "barrel_len": 0.3, "barrel_r": 0.015,
		"mag": Vector3(0.05, 0.16, 0.07), "color": Color(0.12, 0.14, 0.12),
		"hip": Vector3(0.2, -0.2, -0.5),
	},
	{
		"name": "Shotgun",
		"damage": 11.0, "pellets": 8, "fire_rate": 1.3, "automatic": false,
		"spread": 0.04, "moving_spread": 0.0003,
		"mag_size": 6, "reserve": 999999, "reload_time": 0.55, "shell_reload": true,
		"recoil_pitch": 0.25, "recoil_yaw": 0.01, "recovery": 2.0, "kickback": 0.05,
		"impact_force": 6.0,
		"body": Vector3(0.06, 0.1, 0.45), "barrel_len": 0.4, "barrel_r": 0.025,
		"mag": Vector3.ZERO, "color": Color(0.35, 0.22, 0.12),
		"hip": Vector3(0.2, -0.2, -0.5),
	},
]

@export var bullet_range := 200.0
@export var max_recoil := 0.3          # cap on camera kick (radians)

var player: CharacterBody3D
var current := 0
var mags: Array[int] = []
var reserves: Array[int] = []

var cooldown := 0.0
var reloading := false
var switching := false
var lowered := false
var reload_id := 0                     # bumped to cancel an in-progress reload
var recoil := Vector2.ZERO             # x = pitch, y = yaw
var rng := RandomNumberGenerator.new()
var pending_hits: Dictionary = {}      # player id -> damage dealt by the current shot

var camera: Camera3D
var model: Node3D
var muzzle: Marker3D
var flash: OmniLight3D
var ammo_label: Label

# Shortcuts to the current weapon's data and ammo
var w: Dictionary:
	get:
		return WEAPONS[current]
var ammo: int:
	get:
		return mags[current]
	set(v):
		mags[current] = v
var reserve: int:
	get:
		return reserves[current]
	set(v):
		reserves[current] = v

func _ready() -> void:
	camera = get_parent() as Camera3D
	if camera == null:
		push_error("gun.gd must be created by player.gd under the Camera3D. Remove it from '%s'." % get_path())
		set_physics_process(false)
		set_process_unhandled_input(false)
		return
	if player == null:
		# Camera3D -> Head -> Player
		player = camera.get_parent().get_parent() as CharacterBody3D
	rng.randomize()
	for wd in WEAPONS:
		mags.append(int(wd.mag_size))
		reserves.append(int(wd.reserve))
	_build_model()
	_build_hud()
	_update_hud()

# ---------------------------------------------------------------- shared helpers (also used by player.gd and main.gd)

# Builds a weapon model. Used for the first-person gun and for other players' guns.
# The result has a child "Muzzle" (Marker3D) which has a child "Flash" (OmniLight3D).
static func make_model(wd: Dictionary, shadows: bool) -> Node3D:
	var m := Node3D.new()
	var shadow_mode := GeometryInstance3D.SHADOW_CASTING_SETTING_ON if shadows else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

	var mat := StandardMaterial3D.new()
	mat.albedo_color = wd.color
	mat.metallic = 0.5
	mat.roughness = 0.45

	var body_size: Vector3 = wd.body
	var body := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = body_size
	bm.material = mat
	body.mesh = bm
	body.cast_shadow = shadow_mode
	m.add_child(body)

	var barrel_len: float = wd.barrel_len
	var barrel := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = wd.barrel_r
	cm.bottom_radius = wd.barrel_r
	cm.height = barrel_len
	cm.material = mat
	barrel.mesh = cm
	barrel.rotation_degrees = Vector3(90, 0, 0)
	barrel.position = Vector3(0, body_size.y * 0.3, -body_size.z * 0.5 - barrel_len * 0.5 + 0.02)
	barrel.cast_shadow = shadow_mode
	m.add_child(barrel)

	var mag_dims: Vector3 = wd.mag
	if mag_dims != Vector3.ZERO:
		var magazine := MeshInstance3D.new()
		var mm := BoxMesh.new()
		mm.size = mag_dims
		mm.material = mat
		magazine.mesh = mm
		magazine.position = Vector3(0, -body_size.y * 0.5 - mag_dims.y * 0.5 + 0.01, body_size.z * 0.1)
		magazine.cast_shadow = shadow_mode
		m.add_child(magazine)

	var mz := Marker3D.new()
	mz.name = "Muzzle"
	mz.position = Vector3(0, body_size.y * 0.3, -body_size.z * 0.5 - barrel_len + 0.02)
	m.add_child(mz)

	var fl := OmniLight3D.new()
	fl.name = "Flash"
	fl.light_color = Color(1.0, 0.8, 0.4)
	fl.light_energy = 4.0
	fl.omni_range = 6.0
	fl.visible = false
	mz.add_child(fl)
	return m

# Sparks and (optionally) a bullet hole at an impact point.
static func spawn_impact(node: Node, pos: Vector3, normal: Vector3, sparks: bool, leave_hole: bool) -> void:
	var tree := node.get_tree()
	var root := tree.current_scene
	if root == null:
		return

	if sparks:
		var p := CPUParticles3D.new()
		p.one_shot = true
		p.emitting = false
		p.amount = 12
		p.lifetime = 0.35
		p.explosiveness = 1.0
		p.direction = normal
		p.spread = 50.0
		p.initial_velocity_min = 2.0
		p.initial_velocity_max = 5.0
		p.gravity = Vector3(0, -9.8, 0)
		var sm := SphereMesh.new()
		sm.radius = 0.02
		sm.height = 0.04
		var smat := StandardMaterial3D.new()
		smat.albedo_color = Color(1.0, 0.8, 0.3)
		smat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		sm.material = smat
		p.mesh = sm
		root.add_child(p)
		p.global_position = pos
		p.emitting = true
		tree.create_timer(1.0).timeout.connect(p.queue_free)

	# Bullet hole: a small soft dark circle stuck to the surface
	if leave_hole:
		var grad := Gradient.new()
		grad.colors = PackedColorArray([Color(0, 0, 0, 0.9), Color(0, 0, 0, 0)])
		grad.offsets = PackedFloat32Array([0.4, 1.0])
		var tex := GradientTexture2D.new()
		tex.gradient = grad
		tex.fill = GradientTexture2D.FILL_RADIAL
		tex.fill_from = Vector2(0.5, 0.5)
		tex.fill_to = Vector2(0.5, 0.0)

		var hm := StandardMaterial3D.new()
		hm.albedo_texture = tex
		hm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		hm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		hm.cull_mode = BaseMaterial3D.CULL_DISABLED
		var qm := QuadMesh.new()
		qm.size = Vector2(0.12, 0.12)
		qm.material = hm

		var hole := MeshInstance3D.new()
		hole.mesh = qm
		hole.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		root.add_child(hole)
		hole.global_position = pos + normal * 0.005
		var up := Vector3.UP if absf(normal.y) < 0.99 else Vector3.RIGHT
		hole.look_at(hole.global_position - normal, up)
		tree.create_timer(10.0).timeout.connect(hole.queue_free)

# ---------------------------------------------------------------- setup

func _build_model() -> void:
	if model:
		model.queue_free()
	model = make_model(w, false)
	add_child(model)
	var hip: Vector3 = w.hip
	model.position = hip + (LOWERED_OFFSET if lowered else Vector3.ZERO)
	muzzle = model.get_node("Muzzle") as Marker3D
	flash = muzzle.get_node("Flash") as OmniLight3D

func _build_hud() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	ammo_label = Label.new()
	ammo_label.add_theme_font_size_override("font_size", 28)
	ammo_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	layer.add_child(ammo_label)
	ammo_label.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	ammo_label.grow_vertical = Control.GROW_DIRECTION_BEGIN
	ammo_label.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT, Control.PRESET_MODE_MINSIZE, 24)

func _update_hud() -> void:
	var reserve_text := "INF" if reserve > INFINITE_AMMO_THRESHOLD else str(reserve)
	var status := "RELOADING..." if reloading else "%d / %s" % [ammo, reserve_text]
	ammo_label.text = "%s\n%s" % [w.name, status]

# ---------------------------------------------------------------- input

func _player_dead() -> bool:
	return player != null and bool(player.get("dead"))

func _unhandled_input(event: InputEvent) -> void:
	if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED or _player_dead():
		return
	if event.is_action_pressed("weapon_1"):
		_switch_to(0)
	elif event.is_action_pressed("weapon_2"):
		_switch_to(1)
	elif event.is_action_pressed("weapon_3"):
		_switch_to(2)
	elif event.is_action_pressed("weapon_next"):
		_switch_to(current + 1)
	elif event.is_action_pressed("weapon_prev"):
		_switch_to(current - 1)

func _physics_process(delta: float) -> void:
	cooldown -= delta

	if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED and not switching and not _player_dead():
		var trigger := Input.is_action_pressed("shoot") if w.automatic else Input.is_action_just_pressed("shoot")

		# Shotgun: pulling the trigger mid-reload stops the reload and fires
		if reloading and trigger and w.shell_reload and ammo > 0:
			reload_id += 1
			reloading = false
			_update_hud()

		if not reloading:
			if trigger and cooldown <= 0.0:
				if ammo > 0:
					_fire()
				else:
					_start_reload()
			if Input.is_action_just_pressed("reload"):
				_start_reload()

	# Recoil settles back to zero (per-weapon recovery speed, applied to the
	# camera node only so it never fights your mouse aim)
	var recovery: float = w.recovery
	recoil = recoil.lerp(Vector2.ZERO, clampf(recovery * delta, 0.0, 1.0))
	camera.rotation.x = recoil.x
	camera.rotation.y = recoil.y

	# Gun model settles to the hip, or drops while reloading / switching
	var hip: Vector3 = w.hip
	var target_pos := hip + (LOWERED_OFFSET if (reloading or lowered) else Vector3.ZERO)
	model.position = model.position.lerp(target_pos, clampf(15.0 * delta, 0.0, 1.0))

# ---------------------------------------------------------------- shooting

func _fire() -> void:
	ammo -= 1
	cooldown = 1.0 / float(w.fire_rate)
	pending_hits.clear()

	var cam_basis := camera.global_transform.basis
	var spread: float = w.spread
	if player:
		spread += Vector2(player.velocity.x, player.velocity.z).length() * float(w.moving_spread)

	var origin := camera.global_position
	var space := get_world_3d().direct_space_state
	var pellets: int = w.pellets

	var hit_pos := PackedVector3Array()
	var hit_nrm := PackedVector3Array()
	var hit_hole := PackedByteArray()

	for i in pellets:
		# Random point inside a circular cone of spread
		var angle := rng.randf() * TAU
		var radius := sqrt(rng.randf()) * spread
		var dir := -cam_basis.z
		dir += cam_basis.x * cos(angle) * radius + cam_basis.y * sin(angle) * radius
		dir = dir.normalized()

		# The hitscan itself: one instant ray per pellet, no bullet object
		var query := PhysicsRayQueryParameters3D.create(origin, origin + dir * bullet_range)
		if player:
			query.exclude = [player.get_rid()]
		var hit := space.intersect_ray(query)
		if hit:
			var sparks: bool = pellets == 1 or i < 3
			var hole := _on_hit(hit, dir, sparks)
			hit_pos.append(hit.position)
			hit_nrm.append(hit.normal)
			hit_hole.append(1 if hole else 0)

	var scene = get_tree().current_scene
	if scene != null:
		# One damage report per player hit (a shotgun blast is a single report)
		if scene.has_method("hit_player"):
			for id in pending_hits:
				scene.hit_player(int(id), float(pending_hits[id]))
		# Let other players see the muzzle flash and impacts
		if scene.has_method("broadcast_shot"):
			scene.broadcast_shot(current, hit_pos, hit_nrm, hit_hole)

	# Feedback: recoil, kickback, muzzle flash
	var mult := 1.0
	if player and player.get("gun_recoil") != null:
		mult = float(player.get("gun_recoil"))
	recoil.x = minf(recoil.x + float(w.recoil_pitch) * mult, max_recoil)
	recoil.y += rng.randf_range(-float(w.recoil_yaw), float(w.recoil_yaw)) * mult
	model.position.z += float(w.kickback)
	flash.visible = true
	get_tree().create_timer(0.04).timeout.connect(_end_flash)
	_update_hud()

func _end_flash() -> void:
	if flash:
		flash.visible = false

# Returns true if a bullet hole was left
func _on_hit(hit: Dictionary, dir: Vector3, sparks: bool) -> bool:
	var collider = hit.collider
	var pos: Vector3 = hit.position
	var normal: Vector3 = hit.normal

	var is_player: bool = collider.is_in_group("players")
	var damageable: bool = is_player or collider.has_method("take_damage")

	if is_player:
		var id := int(str(collider.name))
		pending_hits[id] = float(pending_hits.get(id, 0.0)) + float(w.damage)
	elif collider.has_method("take_damage"):
		collider.take_damage(float(w.damage))
	if collider is RigidBody3D:
		collider.apply_impulse(dir * float(w.impact_force), pos - collider.global_position)

	# Bullet holes only on static level geometry
	var leave_hole: bool = collider is StaticBody3D and not damageable
	spawn_impact(self, pos, normal, sparks, leave_hole)
	return leave_hole

# ---------------------------------------------------------------- reload / switch

func _start_reload() -> void:
	if reloading or switching or reserve <= 0 or ammo >= int(w.mag_size):
		return
	reloading = true
	reload_id += 1
	var my_id := reload_id
	_update_hud()

	if w.shell_reload:
		# Load one shell at a time (can be interrupted by firing)
		while ammo < int(w.mag_size) and reserve > 0:
			await get_tree().create_timer(float(w.reload_time)).timeout
			if my_id != reload_id:
				return
			ammo += 1
			reserve -= 1
			_update_hud()
	else:
		await get_tree().create_timer(float(w.reload_time)).timeout
		if my_id != reload_id:
			return
		var taken := mini(int(w.mag_size) - ammo, reserve)
		ammo += taken
		reserve -= taken

	reloading = false
	_update_hud()

func _switch_to(i: int) -> void:
	i = posmod(i, WEAPONS.size())
	if i == current or switching:
		return
	switching = true
	reload_id += 1          # cancels any reload in progress
	reloading = false
	lowered = true
	await get_tree().create_timer(0.2).timeout
	current = i
	_build_model()
	cooldown = 0.1
	_update_hud()
	lowered = false
	await get_tree().create_timer(0.2).timeout
	switching = false
