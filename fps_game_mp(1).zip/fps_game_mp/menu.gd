extends Control
## Main menu: host a game, join by IP, or play offline.

const GAME_SCENE := "res://main.tscn"
const NetScript := preload("res://net.gd")

var ip_field: LineEdit
var status: Label
var buttons: Array[Button] = []

func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	multiplayer.connected_to_server.connect(_on_connected)
	multiplayer.connection_failed.connect(_on_failed)
	_build_ui()

func _build_ui() -> void:
	var center := CenterContainer.new()
	add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var box := VBoxContainer.new()
	box.custom_minimum_size = Vector2(340, 0)
	box.add_theme_constant_override("separation", 12)
	center.add_child(box)

	var title := Label.new()
	title.text = "FPS Prototype"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 36)
	box.add_child(title)

	ip_field = LineEdit.new()
	ip_field.text = "127.0.0.1"
	ip_field.placeholder_text = "Host IP address"
	box.add_child(ip_field)

	buttons.append(_add_button(box, "Host Game", _on_host))
	buttons.append(_add_button(box, "Join Game", _on_join))
	buttons.append(_add_button(box, "Play Offline", _on_offline))
	buttons.append(_add_button(box, "Quit", _on_quit))

	status = Label.new()
	status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(status)

func _add_button(parent: Control, text: String, callback: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.pressed.connect(callback)
	parent.add_child(b)
	return b

func _set_buttons_enabled(enabled: bool) -> void:
	for b in buttons:
		b.disabled = not enabled

func _on_host() -> void:
	var err := NetScript.host(multiplayer)
	if err != OK:
		status.text = "Could not host (error %d). Is port %d already in use?" % [err, NetScript.PORT]
		return
	get_tree().change_scene_to_file(GAME_SCENE)

func _on_join() -> void:
	var address := ip_field.text.strip_edges()
	if address == "":
		status.text = "Enter the host's IP address."
		return
	var err := NetScript.join(multiplayer, address)
	if err != OK:
		status.text = "Could not start connecting (error %d)." % err
		return
	status.text = "Connecting to %s..." % address
	_set_buttons_enabled(false)

func _on_offline() -> void:
	NetScript.leave(multiplayer)
	get_tree().change_scene_to_file(GAME_SCENE)

func _on_quit() -> void:
	get_tree().quit()

func _on_connected() -> void:
	get_tree().change_scene_to_file(GAME_SCENE)

func _on_failed() -> void:
	NetScript.leave(multiplayer)
	status.text = "Connection failed. Check the IP, and that the host has started and forwarded port %d." % NetScript.PORT
	_set_buttons_enabled(true)
