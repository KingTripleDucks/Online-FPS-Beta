extends CharacterBody3D
## First-person movement + networked player.
## The peer that owns this node (its multiplayer authority) reads input and
## moves it. Everyone else sees a synced copy with a body, name tag and gun.

const GunScript := preload("res://gun.gd")
const NetScript := preload("res://net.gd")
const SETTINGS_PATH := "user://settings.cfg"
const MENU_SCENE := "res://menu.tscn"
const MAX_HEALTH := 100.0
const SYNC_INTERVAL := 0.05            # 20 network updates per second

enum Stance { STAND, CROUCH, CRAWL }
const STANCE_NAMES := ["Standing", "Crouching", "Crawling"]

@export_group("Speeds")
@export var walk_speed := 5.0
@export var sprint_speed := 8.5
@export var crouch_speed := 2.8
@export var crawl_speed := 1.3
@export var ground_accel := 50.0
@export var air_accel := 12.0

@export_group("Jump")
@export var jump_velocity := 5.0
@export var gravity := 15.0
@export var coyote_time := 0.12
@export var jump_buffer_time := 0.12

@export_group("Slide")
@export var slide_min_speed := 6.0     # must be moving at least this fast to slide
@export var slide_boost := 3.0         # extra speed added when the slide starts
@export var slide_friction := 4.0      # speed lost per second while sliding (ground only)
@export var slide_end_speed := 3.0     # slide ends below this speed
@export var slide_cooldown := 0.4

@export_group("Wall Jump")
@export var wall_jump_cooldown := 0.5  # seconds between wall jumps
@export var wall_jump_push := 6.0      # push away from the wall
@export var wall_jump_up := 6.5
@export var wall_grace_time := 0.15    # how long after touching a wall you can still kick off
@export var wall_slide_speed := 3.0    # max fall speed while pressing into a wall

@export_group("Body")
@export var stand_height := 1.8
@export var crouch_height := 1.2
@export var crawl_height := 0.6
@export var eye_stand := 1.6
@export var eye_crouch := 1.0
@export var eye_crawl := 0.4
@export var eye_slide := 0.7

@export_group("Camera")
@export var mouse_sensitivity := 0.0025  # default; the slider overrides this and saves it
@export var base_fov := 75.0
@export var sprint_fov_boost := 8.0    # added at full sprint speed (scales with speed, also in the air)
@export var slide_fov_boost := 20.0    # added while sliding
@export var fov_in_speed := 10.0       # how fast FOV widens
@export var fov_out_speed := 5.0       # how fast FOV settles back (slower = smoother)

@export_group("Weapons")
@export var gun_recoil := 1.0          # multiplier on every gun's camera kick

# ---- state shared by local and remote copies
var is_local := false
var health := MAX_HEALTH
var dead := false

var stance: int = Stance.STAND
var current_height := 1.8

# ---- local-only state
var menu_open := false
var crawl_toggled := false
var is_sliding := false
var slide_dir := Vector3.ZERO
var slide_speed := 0.0
var slide_cooldown_timer := 0.0
var coyote_timer := 0.0
var buffer_timer := 0.0
var wall_normal := Vector3.ZERO
var wall_grace := 0.0
var wall_jump_timer := 0.0
var spawn_position := Vector3.ZERO
var sync_timer := 0.0
var flash_alpha := 0.0

var gun                                # the local gun (untyped on purpose)
var hud: Label
var death_label: Label
var damage_flash: ColorRect
var settings_layer: CanvasLayer
var sens_slider: HSlider
var sens_label: Label

# ---- remote-only state (what we know about another player)
var net_pos := Vector3.ZERO
var net_yaw := 0.0
var net_pitch := 0.0
var net_vel := Vector3.ZERO
var remote_weapon := -1
var remote_model: Node3D
var remote_flash: OmniLight3D

# ---- visuals for how other players see this one
var body_mesh: MeshInstance3D
var name_tag: Label3D

@onready var col: CollisionShape3D = $CollisionShape3D
@onready var head: Node3D = $Head
@onready var camera: Camera3D = $Head/Camera3D

func _ready() -> void:
	is_local = is_multiplayer_authority()
	add_to_group("players")
	spawn_position = global_position

	_build_body_visuals()
	_set_height(stand_height)
	head.position.y = eye_stand

	if is_local:
		camera.make_current()
		camera.fov = base_fov
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
		body_mesh.visible = false       # you don't see your own body
		name_tag.visible = false
		_load_settings()
		_build_hud()
		_build_settings_menu()
		# Attach the gun to the camera (the gun finds the player on its own)
		gun = GunScript.new()
		camera.add_child(gun)
	else:
		camera.queue_free()             # only the local player needs a camera
		set_process_unhandled_input(false)
		collision_mask = 0              # remote copies don't collide with the world themselves
		net_pos = global_position
		net_yaw = rotation.y

# ---------------------------------------------------------------- how others see this player

func _build_body_visuals() -> void:
	var id := int(str(name))

	body_mesh = MeshInstance3D.new()
	var cm := CapsuleMesh.new()
	cm.radius = 0.3
	cm.height = stand_height
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color.from_hsv(fmod(id * 0.137, 1.0), 0.6, 0.9)
	cm.material = mat
	body_mesh.mesh = cm
	add_child(body_mesh)

	name_tag = Label3D.new()
	name_tag.text = "Player %d" % id
	name_tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	name_tag.pixel_size = 0.005
	name_tag.font_size = 48
	name_tag.no_depth_test = false
	add_child(name_tag)

func _set_remote_weapon(idx: int) -> void:
	remote_weapon = idx
	if remote_model:
		remote_model.queue_free()
	remote_model = GunScript.make_model(GunScript.WEAPONS[idx], true)
	remote_model.position = Vector3(0.25, -0.25, -0.4)
	remote_model.visible = not dead
	head.add_child(remote_model)
	remote_flash = remote_model.get_node("Muzzle/Flash") as OmniLight3D

# Called (via main.gd) when another player fires.
func remote_shot(idx: int) -> void:
	if idx != remote_weapon:
		_set_remote_weapon(idx)
	if remote_flash:
		remote_flash.visible = true
		get_tree().create_timer(0.04).timeout.connect(_end_remote_flash)

func _end_remote_flash() -> void:
	if remote_flash:
		remote_flash.visible = false

# ---------------------------------------------------------------- networking

# The owner sends its state to everyone else; they smooth toward it.
@rpc("authority", "call_remote", "unreliable_ordered")
func sync_state(pos: Vector3, yaw: float, pitch: float, vel: Vector3, height: float, weapon_idx: int) -> void:
	net_pos = pos
	net_yaw = yaw
	net_pitch = pitch
	net_vel = vel
	if not is_equal_approx(height, current_height):
		_set_height(height)
	if weapon_idx != remote_weapon:
		_set_remote_weapon(weapon_idx)

func _remote_physics(delta: float) -> void:
	net_pos += net_vel * delta
	var t := clampf(15.0 * delta, 0.0, 1.0)
	global_position = global_position.lerp(net_pos, t)
	rotation.y = lerp_angle(rotation.y, net_yaw, t)
	head.rotation.x = lerp_angle(head.rotation.x, net_pitch, t)
	head.position.y = lerpf(head.position.y, current_height - 0.2, t)

# Host tells everyone this player's new health.
func set_health(hp: float) -> void:
	if is_local and hp < health:
		flash_alpha = 0.4
	health = hp
	if health <= 0.0 and not dead:
		_die()

func _die() -> void:
	dead = true
	collision_layer = 0                 # bullets pass through the dead
	body_mesh.visible = false
	name_tag.visible = false
	if remote_model:
		remote_model.visible = false
	if is_local:
		is_sliding = false
		death_label.visible = true

func respawn(pos: Vector3) -> void:
	dead = false
	health = MAX_HEALTH
	collision_layer = 1
	global_position = pos
	velocity = Vector3.ZERO
	net_pos = pos
	if is_local:
		is_sliding = false
		crawl_toggled = false
		death_label.visible = false
	else:
		body_mesh.visible = true
		name_tag.visible = true
		if remote_model:
			remote_model.visible = true

# ---------------------------------------------------------------- settings

func _load_settings() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SETTINGS_PATH) == OK:
		mouse_sensitivity = float(cfg.get_value("controls", "sensitivity", mouse_sensitivity))

func _save_settings() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("controls", "sensitivity", mouse_sensitivity)
	cfg.save(SETTINGS_PATH)

func _build_settings_menu() -> void:
	settings_layer = CanvasLayer.new()
	settings_layer.layer = 10
	settings_layer.visible = false
	add_child(settings_layer)

	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(360, 0)
	panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	panel.grow_vertical = Control.GROW_DIRECTION_BOTH

	var margin := MarginContainer.new()
	for side in ["margin_left", "margin_right", "margin_top", "margin_bottom"]:
		margin.add_theme_constant_override(side, 20)
	panel.add_child(margin)

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 12)
	margin.add_child(box)

	var title := Label.new()
	title.text = "Settings"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 24)
	box.add_child(title)

	sens_label = Label.new()
	box.add_child(sens_label)

	sens_slider = HSlider.new()
	sens_slider.min_value = 0.2
	sens_slider.max_value = 10.0
	sens_slider.step = 0.1
	sens_slider.value = mouse_sensitivity * 1000.0
	sens_slider.custom_minimum_size = Vector2(300, 24)
	sens_slider.value_changed.connect(_on_sensitivity_changed)
	box.add_child(sens_slider)
	sens_label.text = "Mouse sensitivity: %.1f" % sens_slider.value

	var resume := Button.new()
	resume.text = "Resume"
	resume.pressed.connect(_on_resume_pressed)
	box.add_child(resume)

	var leave := Button.new()
	leave.text = "Leave Game"
	leave.pressed.connect(_leave_game)
	box.add_child(leave)

	settings_layer.add_child(panel)
	panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER, Control.PRESET_MODE_MINSIZE)

func _on_sensitivity_changed(value: float) -> void:
	mouse_sensitivity = value * 0.001
	sens_label.text = "Mouse sensitivity: %.1f" % value

func _on_resume_pressed() -> void:
	_set_menu(false)

# In multiplayer the world keeps running while the menu is open, so this
# only blocks your own input instead of pausing the game.
func _set_menu(open: bool) -> void:
	menu_open = open
	settings_layer.visible = open
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if open else Input.MOUSE_MODE_CAPTURED
	if not open:
		_save_settings()

func _leave_game() -> void:
	_save_settings()
	NetScript.leave(multiplayer)
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	get_tree().change_scene_to_file(MENU_SCENE)

# ---------------------------------------------------------------- HUD / input

func _build_hud() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)

	damage_flash = ColorRect.new()
	damage_flash.color = Color(1, 0, 0, 0)
	damage_flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(damage_flash)
	damage_flash.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	hud = Label.new()
	hud.position = Vector2(12, 12)
	layer.add_child(hud)

	var dot := ColorRect.new()
	dot.custom_minimum_size = Vector2(4, 4)
	dot.size = Vector2(4, 4)
	dot.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(dot)
	dot.set_anchors_and_offsets_preset(Control.PRESET_CENTER)

	death_label = Label.new()
	death_label.text = "YOU DIED - respawning..."
	death_label.add_theme_font_size_override("font_size", 40)
	death_label.visible = false
	death_label.grow_horizontal = Control.GROW_DIRECTION_BOTH
	layer.add_child(death_label)
	death_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER)

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		_set_menu(not menu_open)
	elif menu_open or dead:
		return
	elif event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		rotate_y(-event.relative.x * mouse_sensitivity)
		head.rotate_x(-event.relative.y * mouse_sensitivity)
		head.rotation.x = clampf(head.rotation.x, deg_to_rad(-89.0), deg_to_rad(89.0))
	elif event is InputEventMouseButton and event.pressed:
		# Re-grab the mouse if the window lost focus
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

# Input helpers: ignored while the menu is open or you're dead
func _held(action: String) -> bool:
	return not menu_open and not dead and Input.is_action_pressed(action)

func _tapped(action: String) -> bool:
	return not menu_open and not dead and Input.is_action_just_pressed(action)

# ---------------------------------------------------------------- movement

func _physics_process(delta: float) -> void:
	if not is_local:
		_remote_physics(delta)
		return

	# Respawn if you fall off the map
	if global_position.y < -30.0:
		global_position = spawn_position
		velocity = Vector3.ZERO

	# ---- timers ----
	if is_on_floor():
		coyote_timer = coyote_time
	else:
		coyote_timer -= delta
	buffer_timer -= delta
	slide_cooldown_timer -= delta
	wall_grace -= delta
	wall_jump_timer -= delta

	if _tapped("jump"):
		buffer_timer = jump_buffer_time
	if _tapped("crawl"):
		crawl_toggled = not crawl_toggled

	# ---- input ----
	var input_dir := Vector2.ZERO
	if not menu_open and not dead:
		input_dir = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var direction := (transform.basis * Vector3(input_dir.x, 0.0, input_dir.y)).normalized()
	var h_speed := Vector2(velocity.x, velocity.z).length()

	# ---- jumping (ground jump, coyote jump, wall jump) ----
	if buffer_timer > 0.0:
		if crawl_toggled and is_on_floor():
			# Jump key while crawling = stand up instead of jumping
			crawl_toggled = false
			buffer_timer = 0.0
		elif coyote_timer > 0.0:
			# Jumping out of a slide keeps the slide going in the air
			velocity.y = jump_velocity
			coyote_timer = 0.0
			buffer_timer = 0.0
		elif wall_grace > 0.0 and wall_jump_timer <= 0.0:
			is_sliding = false  # wall jump ends the slide so the kick-off isn't overridden
			velocity = Vector3(wall_normal.x * wall_jump_push, wall_jump_up, wall_normal.z * wall_jump_push)
			wall_jump_timer = wall_jump_cooldown
			wall_grace = 0.0
			buffer_timer = 0.0

	var grounded := is_on_floor() and velocity.y <= 0.0

	# ---- gravity + wall slide ----
	if not grounded:
		velocity.y -= gravity * delta
		if wall_grace > 0.0 and velocity.y < -wall_slide_speed and direction.dot(-wall_normal) > 0.3:
			velocity.y = -wall_slide_speed

	# ---- start a slide: sprint into crouch ----
	if _tapped("crouch") and grounded and not is_sliding \
			and slide_cooldown_timer <= 0.0 and not crawl_toggled and h_speed >= slide_min_speed:
		is_sliding = true
		slide_dir = Vector3(velocity.x, 0.0, velocity.z).normalized()
		slide_speed = h_speed + slide_boost

	# ---- stance (collision height) ----
	var want := Stance.STAND
	if crawl_toggled:
		want = Stance.CRAWL
	elif _held("crouch") or is_sliding:
		want = Stance.CROUCH
	_apply_stance(want)

	# ---- horizontal movement ----
	var sprinting := false
	if is_sliding:
		# Friction only applies on the ground; in the air you carry your slide speed
		if grounded:
			slide_speed -= slide_friction * delta
		if slide_speed <= slide_end_speed or not _held("crouch") or is_on_wall():
			is_sliding = false
			slide_cooldown_timer = slide_cooldown
		else:
			velocity.x = slide_dir.x * slide_speed
			velocity.z = slide_dir.z * slide_speed

	if not is_sliding:
		var h := Vector2(velocity.x, velocity.z)
		if grounded:
			var speed := walk_speed
			match stance:
				Stance.CRAWL:
					speed = crawl_speed
				Stance.CROUCH:
					speed = crouch_speed
				_:
					sprinting = _held("sprint") and input_dir.y < -0.1
					speed = sprint_speed if sprinting else walk_speed
			h = h.move_toward(Vector2(direction.x, direction.z) * speed, ground_accel * delta)
		else:
			# Air control: steer freely but never gain speed beyond what you had
			var prev := h.length()
			h += Vector2(direction.x, direction.z) * air_accel * delta
			var cap := maxf(prev, walk_speed)
			if h.length() > cap:
				h = h.normalized() * cap
		velocity.x = h.x
		velocity.z = h.y

	move_and_slide()

	# ---- remember wall contact for wall jumps ----
	if not is_on_floor() and is_on_wall():
		wall_normal = get_wall_normal()
		wall_grace = wall_grace_time

	# ---- camera feel ----
	var eye := eye_stand
	if is_sliding:
		eye = eye_slide
	elif stance == Stance.CROUCH:
		eye = eye_crouch
	elif stance == Stance.CRAWL:
		eye = eye_crawl
	head.position.y = lerpf(head.position.y, eye, 12.0 * delta)

	# FOV: widens with speed (sprinting, and sprint-jumps in the air), bigger kick while sliding
	var speed_now := Vector2(velocity.x, velocity.z).length()
	var speed_t := clampf(inverse_lerp(walk_speed, sprint_speed, speed_now), 0.0, 1.0)
	var target_fov := base_fov + sprint_fov_boost * speed_t
	if is_sliding:
		target_fov = base_fov + slide_fov_boost
	var fov_speed := fov_in_speed if target_fov > camera.fov else fov_out_speed
	camera.fov = lerpf(camera.fov, target_fov, fov_speed * delta)

	# ---- tell the other players where we are ----
	sync_timer += delta
	if sync_timer >= SYNC_INTERVAL:
		sync_timer = 0.0
		if multiplayer.get_peers().size() > 0:
			var widx := 0
			if gun != null:
				widx = int(gun.current)
			sync_state.rpc(global_position, rotation.y, head.rotation.x, velocity, current_height, widx)

func _process(delta: float) -> void:
	if not is_local:
		return
	flash_alpha = move_toward(flash_alpha, 0.0, delta * 1.0)
	damage_flash.color.a = flash_alpha

	var state: String = STANCE_NAMES[stance]
	if is_sliding:
		state = "Sliding"
	elif not is_on_floor():
		state = "Airborne"
	var wall_text := "ready" if wall_jump_timer <= 0.0 else "%.1fs" % wall_jump_timer
	var player_count := get_tree().get_nodes_in_group("players").size()
	hud.text = "Health: %d\nState: %s\nSpeed: %.1f m/s\nWall jump: %s\nPlayers: %d\n\nWASD move | Shift sprint | Space jump\nC/Ctrl crouch (sprint + crouch = slide)\nZ toggle crawl | Esc menu\n1/2/3 or wheel: weapons | R reload" % [
		int(health), state, Vector2(velocity.x, velocity.z).length(), wall_text, player_count]

func _height_for(s: int) -> float:
	match s:
		Stance.CRAWL:
			return crawl_height
		Stance.CROUCH:
			return crouch_height
		_:
			return stand_height

func _set_height(h: float) -> void:
	var shape := col.shape as CapsuleShape3D
	shape.height = h
	col.position.y = h * 0.5
	current_height = h
	if body_mesh:
		(body_mesh.mesh as CapsuleMesh).height = h
		body_mesh.position.y = h * 0.5
	if name_tag:
		name_tag.position.y = h + 0.3

# Switch stance, but never stand up into a ceiling: if the taller
# stance is blocked, fall back to the tallest one that fits.
func _apply_stance(want: int) -> void:
	for s in range(want, Stance.CRAWL + 1):
		var h := _height_for(s)
		if h > current_height + 0.001:
			if test_move(global_transform, Vector3.UP * (h - current_height + 0.02)):
				continue
		if not is_equal_approx(h, current_height):
			_set_height(h)
		stance = s
		return
